<?php

namespace App\Http\Controllers;

use App\Models\LogPengajuan;
use App\Http\Requests\StoreLogPengajuanRequest;
use App\Http\Requests\UpdateLogPengajuanRequest;

class LogPengajuanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreLogPengajuanRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(LogPengajuan $logPengajuan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(LogPengajuan $logPengajuan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateLogPengajuanRequest $request, LogPengajuan $logPengajuan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(LogPengajuan $logPengajuan)
    {
        //
    }
}
