<?php $__env->startSection('admin'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

<nav class="page-breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="#">Tables</a></li>
    <li class="breadcrumb-item active" aria-current="page">Data Table</li>
  </ol>
</nav>

<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title">User</h6>
        
        
        <div class="table-responsive">
            <table id="dataTableExample" class="table">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Nama Pembimbing</th>
                  <th>Nama Siswa</th>
                  <th>Dokumen</th>
                  <th>Status</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i->id); ?></td>
                    <td><?php echo e($i->nama_pembimbing); ?></td>
                    <td><?php echo e($i->nama_siswa); ?></td>
                    <td>
                      <a href="<?php echo e(URL::asset("upload/dokumen-pengajuan/$i->dokumen")); ?>" download><?php echo e($i->dokumen); ?></a>
                    </td>
                    <td><?php echo e($i->status_pengajuan); ?></td>
                    <td>
                      <div class="btn-group" role="group" aria-label="Basic Example">
                        <button type="button" class="btn btn-warning btn-icon user_edit">
                          <a href="<?php echo e(route('detailPengajuan',$i->id)); ?>" id="editInstansi" style="color: black"><i class="btn-icon-prepend" data-feather="edit"></i></a>
                        </button>
                    </td>
                      </tr>
                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Putra\Desktop\pkl-management\resources\views/admin/data_master/pengajuan_master.blade.php ENDPATH**/ ?>