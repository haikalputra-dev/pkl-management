
<?php $__env->startSection('instansi'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/admin/pengajuan">Pengajuan</a></li>
            <li class="breadcrumb-item active" aria-current="page">Detail Pengajuan</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Timeline</h6>
                    <form action="<?php echo e(route('updatePengajuanInst',$pengajuan->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Komentar</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" name="komentar"></textarea>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Dokumen</label>
                                <a href="<?php echo e(URL::asset("upload/dokumen-pengajuan/$pengajuan->dokumen")); ?>" download><?php echo e($pengajuan->dokumen); ?></a>
                            </div>
                        </div>
                    </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="mb-3">
                                <select class="form-select" id="exampleFormControlSelect1" name="status_pengajuan" hidden>
                                    <option value="Draft" <?php echo e($pengajuan->status_pengajuan === "Draft" ? "selected" : ""); ?>>Draft</option>
                                    <option value="Diserahkan" <?php echo e($pengajuan->status_pengajuan === "Diserahkan" ? "selected" : ""); ?>>Diserahkan</option>
                                    <option value="Ditunda" <?php echo e($pengajuan->status_pengajuan === "Ditunda" ? "selected" : ""); ?>>Ditunda</option>
                                    <option value="Diterima" <?php echo e($pengajuan->status_pengajuan === "Diterima" ? "selected" : ""); ?>>Diterima</option>
                                    <option value="Ditolak" <?php echo e($pengajuan->status_pengajuan === "Ditolak" ? "selected" : ""); ?>>Ditolak</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Tambah Komentar</button>
                </form>
                    <div id="content">
                    <ul class="timeline">
                        <?php $__currentLoopData = $log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="event" data-date="<?php echo e($i->timestamp); ?>">
                        <h3 class="title"><?php echo e($i->status_log); ?></h3>
                        <p class="text-secondary">from: <?php echo e($i->username); ?></p>
                        <p><?php echo e($i->komentar); ?></p>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('instansi.instansi_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Putra\Desktop\pkl-management\resources\views/instansi/detail_pengajuan_instansi.blade.php ENDPATH**/ ?>