  
  <?php $__env->startSection('admin'); ?>
  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

  <div class="row">
    <div class="col-md-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h6 class="card-title">Tim PKL </h6>
          
          <button type="button" class="btn btn-primary btn-icon-text mb-3" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <i class="btn-icon-prepend" data-feather="plus-circle"></i>
            Tambah Data
          </button>
          <div class="table-responsive">
            <table id="dataTableExample" class="table">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Nama Instansi</th>
                  <th>Nama Pembimbing</th>
                  <th>Nama Siswa</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $resultData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                  <td><?php echo e($i['id']); ?></td>
                  <td><?php echo e(implode(', ', $i['nama_instansi'])); ?></td>
                  <td><?php echo e(implode(', ', $i['nama_pembimbing'])); ?></td>
                  <td><?php echo e(implode(', ', $i['nama_siswa'])); ?></td>
                  <td>
                    <div class="btn-group" role="group" aria-label="Basic Example">
                      <button type="button" class="btn btn-warning btn-icon user_edit">
                        <a href="" id="editInstansi" data-bs-toggle="modal" data-bs-target="#editModal-<?php echo e($i['id']); ?>" data-id="<?php echo e($i['id']); ?>" style="color: black"><i class="btn-icon-prepend" data-feather="edit"></i></a>
                      </button>
                      <a href="<?php echo e(route('deleteTim',$i['id'])); ?>" data-confirm-delete="true" class="btn btn-danger btn-icon"><i class="btn-icon-prepend" data-confirm-delete="true" data-feather="trash-2" ></i></a>
                      <!-- Modal -->
                        <div class="modal fade" id="editModal-<?php echo e($i['id']); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="btn-close"></button>
                              </div>
                              <div class="modal-body">
                                <form class="forms-sample" action="/admin/user/<?php echo e($i['id']); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="tutupEdit">Close</button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                              </div>
                            </div>
                          </form>
                          </div>
                        </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form class="forms-sample" action="/admin/tim" method="POST">
      <?php echo csrf_field(); ?>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="btn-close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="instansi-dropdown" class="form-label">Instansi</label>
          <select class="form-select" id="instansi-dropdown" name="id_instansi">
            <option value="" selected disabled>---PILIH INSTANSI---</option>
            <?php $__currentLoopData = $instansi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>"><?php echo e($u->nama_instansi); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="mb-3">
            <label for="pembimbing-dropdown" class="form-label">Pembimbing</label>
            <select class="form-select" id="pembimbing-dropdown" name="id_pembimbing">
            </select>
          </div>
          <div class="mb-3">
            <label for="siswa-dropdown" class="form-label">Siswa</label>
            <select class="form-select" id="siswa-dropdown1" name="id_siswa[]">
            </select>
          </div>
          <button type="button" id="cloneSelect" class="btn btn-info">Tambah Siswa</button>
          <button type="button" id="cloneSelectRemove" class="btn btn-warning">-</button>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-primary">Tambah</button>
      </div>
    </div>
  </form>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Putra\Desktop\pkl-management\resources\views/admin/data_master/tim_master.blade.php ENDPATH**/ ?>